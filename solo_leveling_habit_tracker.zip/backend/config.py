DB_CONFIG = {
    'MYSQL_HOST': 'localhost',
    'MYSQL_USER': 'your_username',
    'MYSQL_PASSWORD': 'your_password',
    'MYSQL_DB': 'solo_leveling'
}